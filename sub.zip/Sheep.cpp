
#include "Sheep.h"
int Sheep::static_price=5;
Sheep::~Sheep() {

}

int Sheep::get_static_price() {
    return static_price;
}
