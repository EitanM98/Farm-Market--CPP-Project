//
// Created by ise on 12/28/21.
//

#include "Milk.h"

Milk::~Milk() {

}
