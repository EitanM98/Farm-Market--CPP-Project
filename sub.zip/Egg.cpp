//
// Created by ise on 12/28/21.
//

#include "Egg.h"

Egg::~Egg() {

}
